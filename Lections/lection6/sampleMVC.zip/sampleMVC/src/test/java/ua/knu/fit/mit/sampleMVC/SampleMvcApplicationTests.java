package ua.knu.fit.mit.sampleMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
