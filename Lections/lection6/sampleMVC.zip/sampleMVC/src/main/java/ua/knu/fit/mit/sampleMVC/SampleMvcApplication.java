package ua.knu.fit.mit.sampleMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleMvcApplication.class, args);
	}

}
